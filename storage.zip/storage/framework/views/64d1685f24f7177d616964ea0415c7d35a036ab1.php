<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Quiz')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <form action="<?php echo e(route('encuesta.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="container flex flex-wrap ">
            <div class="m-1 sm:p-0 xl:p-20">
                
                <br>
                  <?php if(auth()->user()->roles[0]->name == 'admin'): ?>
                <div class="flex-col flex">
                    <div class="block">
                        <a class="text-yellow-600 hover:text-yellow-900 bg-yellow-100 rounded-lg py-1 px-3 float-left" href="<?php echo e(route('encuesta.create')); ?>">
                            Editar
                        </a>
                    </div>
                </div>
                    <?php endif; ?>
                <div class="border-solid border-2 rounded-lg dark:border-indigo-900 m-5 bg-violet-100">
                <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   

                        <?php if($i == 0): ?>
                            <div class="text-center text-xl leading-7 font-semibold text-indigo-50 bg-indigo-900">
                                <?php echo e($pregunta->categoryQuestion->name); ?>

                            </div>
                            <hr class="border-indigo-900">
                            <br>
                        <?php else: ?>
                            <?php if($questions[$i - 1]->categoryQuestion->name != $pregunta->categoryQuestion->name): ?>
                                <div class="text-center text-xl leading-7 font-semibold  text-indigo-50 bg-indigo-900">
                                    <?php echo e($pregunta->categoryQuestion->name); ?> </div>
                                <hr class="border-indigo-900">
                                <br>
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endif; ?>


                       

                        <br>
                        <div class="">  
                            <!-- Preguntas -->
                             <div class=" text-center  ml-4 text-md leading-7 font-semibold"><?php echo e($i +1); ?>.- <?php echo e($pregunta->question); ?></div>
                            <div class=" text-gray-600 dark:text-gray-400 text-sm ">
                                <div class="form-check">
                                    <div class="grid grid-cols-1 sm:grid-cols-1 xl:grid-cols-4 text-center "
                                        id="divGrid<?php echo e($pregunta->id); ?>">
                                        <!-- Respuestas -->
                                        <?php $__currentLoopData = $pregunta->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border-solid border-2 border-indigo-900  hover:bg-indigo-400 hover:text-indigo-50 m-5 p-5 rounded-lg text-left"
                                                onclick="option(answer=<?php echo e($answer); ?>, pregunta = <?php echo e($pregunta->id); ?>)"
                                                id="divOption<?php echo e($answer->id); ?>" style="cursor: pointer">

                                                <input type="hidden" name="category<?php echo e($pregunta->id); ?>" value="<?php echo e($pregunta->categoryQuestion->name); ?>">
                                                   
                                                <input class="form-check-input" type="radio"
                                                    name="pregunta<?php echo e($pregunta->id); ?>" id="<?php echo e($answer->id); ?>"
                                                    value="<?php echo e($answer->option); ?>" >
                                                <label class="form-check-label" for="<?php echo e($answer->id); ?>">
                                                    <?php echo e($answer->option); ?></label>
                                                    <?php if($answer->option == 1): ?>
                                                        <strong>(MUY BUENA)</strong>
                                                    <?php endif; ?>
                                                    <?php if($answer->option == 2): ?>
                                                        <strong>(BUENA)</strong>
                                                    <?php endif; ?>
                                                    <?php if($answer->option == 3): ?>
                                                        <strong>(REGULAR)</strong>
                                                    <?php endif; ?>
                                                    <?php if($answer->option == 4): ?>
                                                        <strong>(MALA)</strong>
                                                    <?php endif; ?>
                                                   
                                                    
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($pregunta->subQuestion): ?>
                                            <br>
                                            <?php $__currentLoopData = $pregunta->subQuestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="ml-4 text-sm leading-7 font-semibold">
                                                    <?php echo e($item->question); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>


                                </div>
                            </div>
                        </div>
                        <br>
                        <br>
                   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?> 
               
             </div>
             <div class="grid grid-cols-4">
                <button type="submit" class="col-start-2 col-span-2 bg-indigo-700 hover:bg-indigo-900 text-indigo-50 rounded-lg border-2 p-2">
                    <?php echo e(__('Enviar')); ?>

                </button>
             </div>
            </div>
          
        </div>

       

    </form>
    <script>
        let questions = [];
        const stilesBg = 'bg-indigo-500';
        const stilesText = 'text-indigo-50';
        let anterior;
        const option = (answer, pregunta) => {
            
            let idanswer = document.getElementById(answer.id);
            let divOption = document.getElementById(`divOption${answer.id}`);
            let divGrid = document.getElementById(`divGrid${pregunta}`);
            let elemento = document.getElementById(`complement${pregunta}`);
            
            if (questions.length == 0) {
                divOption.classList.add(stilesBg, stilesText);
                questions.push({
                    id: pregunta,
                    answer: answer.id,
                    flag_to_complement: answer.flag_to_complement
                });
               
                complement(answer, pregunta, divGrid,idanswer);
                

            } 
            else {

                let findQuestions = questions.find(question => question.id == pregunta);
                if (findQuestions != undefined) {
                    document.getElementById(`divOption${findQuestions.answer}`).classList.remove(stilesBg, stilesText);
                    //idanswer.checked = true;
                    divOption.classList.add(stilesBg, stilesText);
                    complement(answer, findQuestions.id, divGrid,idanswer);
                    findQuestions.answer = answer.id;
                    findQuestions.flag_to_complement =answer.flag_to_complement;
                } 
                
                else {
                  //  idanswer.checked = true;
                    divOption.classList.add(stilesBg, stilesText);
                    questions.push({
                        id: pregunta,
                        answer: answer.id,
                        flag_to_complement: answer.flag_to_complement
                    });

                    complement(answer, pregunta, divGrid,idanswer);
                }
            }



        }

        const complement = (answer, pregunta, divGrid, idanswer) => {
           idanswer.setAttribute('checked', true);
            let elemento = document.getElementById(`complement${pregunta}`);
            if (!elemento) {
               
                if (answer.flag_to_complement == 1) {
                   
                    divGrid.innerHTML +=
                        `   <input type="text" class="sm:row-start-6 sm:col-span-1 xl:row-start-3 xl:col-span-4    
                                m-5 p-5 rounded-lg text-left" name="complement${pregunta}"
                               id="complement${pregunta}" placeholder="Escribe otra opción">`;
                               
                }
            } else {

                elemento.remove();
            }

        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\encuestaEgresdos\resources\views/encuesta/index.blade.php ENDPATH**/ ?>