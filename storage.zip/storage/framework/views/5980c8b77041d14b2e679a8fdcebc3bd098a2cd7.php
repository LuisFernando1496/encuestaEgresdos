 <?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

     <link rel="stylesheet" href="<?php echo e(asset('css/style_login.css')); ?>">
     
   
   
    
     <section class="ftco-section">
         <div class="container">
             <div class="row justify-content-center">
                 <div class="col-md-7 text-center mb-5">
                    <h2 class="heading-section">SISTEMA PARA EL SEGIMIENTO DE EGRESADOS</h2>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-5']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <?php if(session('status')): ?>
                        <div class="mb-4 font-medium text-sm text-green-600">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
          
                 </div>
             </div>
             <div class="row justify-content-center">
                 <div class="col-md-12 col-lg-10">
                     <div class="wrap d-md-flex">
                         <div class="img" style="background-image: url(img/img-sistemas.png);">
                         </div>
                         <div class="login-wrap p-4 p-md-5">
                             <div class="d-flex">
                                 <div class="w-100">
                                     <h3 class="mb-4">Login</h3>
                                 </div>

                             </div>
                            
                        
                               
                             <form method="POST" action="<?php echo e(route('login')); ?>" class="signin-form">
                                 <?php echo csrf_field(); ?>

                                 <div class="form-group mb-3">
                                     <label class="label" for="name"><?php echo e(__('Email')); ?></label>
                                     <input type="text" class="form-control" placeholder="ejemplo@gmail.com"
                                         name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                 </div>
                                 <div class="form-group mb-3">
                                     <label class="label" for="password"><?php echo e(__('Password')); ?></label>
                                     <input type="password" class="form-control" placeholder="Password" name="password" required>
                                 </div>
                                 <div class="form-group">
                                     <button type="submit" class="form-control btn btn-primary rounded submit px-3"> <?php echo e(__('Log in')); ?>

                                        </button>
                                 </div>
                                 <div class="form-group d-md-flex">
                                     <div class="w-50 text-left">
                                         <label class="checkbox-wrap checkbox-primary mb-0"><?php echo e(__('Remember me')); ?>

                                             <input type="checkbox" id="remember_me" name="remember">
                                             <span class="checkmark"></span>
                                         </label>
                                     </div>
                                     <div class="w-50 text-md-right">
                                         
                                         <a href="<?php echo e(route('password.request')); ?>"> <?php echo e(__('Forgot your password?')); ?></a>
                                         
                                     </div>
                                 </div>
                             </form>
                           
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>

  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH D:\encuestaEgresdos\resources\views/auth/login.blade.php ENDPATH**/ ?>