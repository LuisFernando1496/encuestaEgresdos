<table>
    <tr>
        <td>
            <img src="img/logo-ittg.jpeg" width="70px">
        </td>
        <td colspan="8" style="
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            "
        >
            <strong>
                <h1>Instituto Tecnológico De México (Tuxtla Gutiérrez)</h1>
            </strong>
        </td>
        <td>
            <img src="img/Logo-TecNM.jpeg" width="130px">
        </td>
    </tr>
    <?php
        $val = '';
        $val_cat = '';
    ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value->num_control != $val): ?>
            <tr></tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <strong>Num_Control: <?php echo e($value->num_control); ?></strong>
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <strong>Nombre: <?php echo e($value->name); ?></strong>
                </td>
            </tr>
        <?php endif; ?>
        <?php
            $val = $value->num_control;
        ?>
        <?php if($value->category != $val_cat): ?>
            <tr>
                <td></td>
                <td colspan="8"><?php echo e($value->category); ?></td>
            </tr>
        <?php endif; ?>
        <tr>
            <td></td>
            <td colspan="8"><?php echo e($value->question); ?></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td>Respuesta.- <?php echo e($value->answer); ?></td>
        </tr>
        <?php
            $val_cat = $value->category;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr></tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>
            <img class="chart" src="img/<?php echo e($filename); ?>" width="850px">
        </td>    
    </tr>
    
</table><?php /**PATH D:\encuestaEgresdos\resources\views/Plantilla_Export/excel.blade.php ENDPATH**/ ?>