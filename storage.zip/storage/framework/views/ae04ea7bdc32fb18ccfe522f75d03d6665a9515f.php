

<div class="mt-3">
   
    <?php $__empty_1 = true; $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <?php if($mensaje->to_id == $userTo && $mensaje->by_id==$userLoged): ?>
            <div class="chat-message">
                <div class="flex items-end justify-end">
                    <div class="flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end">
                        <div><span
                                class="px-4 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white "><?php echo e($mensaje->mensaje); ?></span>
                        </div>
                    </div>
                    
                </div>
            </div>
        <?php endif; ?>
        
        <?php if($mensaje->to_id == $userLoged && $mensaje->by_id==$userTo): ?>
            <div class="chat-message">
                <div class="flex items-end">
                    <div class="flex flex-col space-y-2 text-xs max-w-xs mx-2 order-2 items-start">
                        <div><span
                                class="px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600"><?php echo e($mensaje->mensaje); ?></span>
                        </div>
                    </div>
                    <img src="https://images.unsplash.com/photo-1549078642-b2ba4bda0cdb?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=3&amp;w=144&amp;h=144"
                        alt="My profile" class="w-6 h-6 rounded-full order-1">
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        Sin mensajes
    <?php endif; ?>
</div>
<?php /**PATH D:\encuestaEgresdos\resources\views/livewire/chat-list.blade.php ENDPATH**/ ?>