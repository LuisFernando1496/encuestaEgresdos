<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Quiz')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="max-w-8xl sm:px-6 lg:px-8 my-5">
        <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php if($i == 0): ?>
                    <div class="flex flex-col">
                        <div class="my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <div class="flex bg-white px-4 py-3 border-t border-gray-200 sm:px-4">
                                        <label for=""><?php echo e($pregunta->categoryQuestion->name); ?></label>
                                        <div class="space-x-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                <?php if($questions[$i - 1]->categoryQuestion->name != $pregunta->categoryQuestion->name): ?>
                    <div class="flex flex-col">
                        <div class="my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <div class="flex bg-white px-4 py-3 border-t border-gray-200 sm:px-4">
                                        <label for=""><?php echo e($pregunta->categoryQuestion->name); ?></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                <?php endif; ?>
                <?php endif; ?>
                <div class="px-6 py-4 text-left">
                    <div>
                        <label for="" class="px-3">Pregunta</label>
                        <form action="<?php echo e(route('question.update', $pregunta->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <input type="text" name="question" value="<?php echo e($pregunta->question); ?>" class="form-input rounded-md shadow-sm mt-1 block w-full"/>
                            <div class="px-6 py-1 whitespace-nowrap text-right">
                                <button 
                                    class="px-6 py-2 whitespace-nowrap text-right px-4 text-green-600 hover:text-green-900 bg-emerald-100 rounded-lg py-1 px-3"
                                    id="btnQuestion"
                                    type="submit"
                                >
                                    Editar    
                                </button>
                            </div>
                        </form>
                        <label for="" class="px-3">Respuestas</label><br><br>
                        <?php $__currentLoopData = $pregunta->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form class="inline-flex rounded-md" action="<?php echo e(route('answers.update', $answer->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>   
                                <input type="hidden" name="question_id" value="<?php echo e($answer->question_id); ?>"/>
                                <input type="text" name="option" value="<?php echo e($answer->option); ?>" class="form-input rounded-md shadow-sm mt-1 block w-full" id="respuesta<?php echo e($answer->id); ?>"/>
                                <div class="px-6 py-1 whitespace-nowrap text-right">
                                    <button 
                                        class="px-6 py-2 whitespace-nowrap text-right px-4 text-orange-600 hover:text-orange-900 bg-yellow-100 rounded-lg py-1 px-3"
                                        type="submit"
                                    >
                                        Editar    
                                    </button>
                                </div>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\encuestaEgresdos\resources\views/encuesta/show_edit.blade.php ENDPATH**/ ?>