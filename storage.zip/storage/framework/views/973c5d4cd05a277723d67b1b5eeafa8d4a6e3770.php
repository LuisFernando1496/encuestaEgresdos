<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div class="mx-3 my-3">
        
    <div class="row">
        <div class="col-md-6">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-form")->html();
} elseif ($_instance->childHasBeenRendered('nlIxsLU')) {
    $componentId = $_instance->getRenderedChildComponentId('nlIxsLU');
    $componentTag = $_instance->getRenderedChildComponentTagName('nlIxsLU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nlIxsLU');
} else {
    $response = \Livewire\Livewire::mount("chat-form");
    $html = $response->html();
    $_instance->logRenderedChild('nlIxsLU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="col-md-6">
           
        </div>
    </div>
    
</div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\encuestaEgresdos\resources\views/chat/index.blade.php ENDPATH**/ ?>